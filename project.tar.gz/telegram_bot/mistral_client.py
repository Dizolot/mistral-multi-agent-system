import aiohttp
import json
import logging
import asyncio
import nest_asyncio
from typing import Dict, Any, List, Optional

# Проверяем, импортирован ли уже async_utils
try:
    from multi_agent_system.async_utils import get_or_create_event_loop, sync_to_async
    use_async_utils = True
except ImportError:
    # Если модуль не найден, применяем nest_asyncio напрямую
    nest_asyncio.apply()
    use_async_utils = False

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('mistral_client')

class MistralClient:
    """
    Асинхронный клиент для взаимодействия с API Mistral
    """
    
    def __init__(self, base_url: str, timeout: int = 180):
        """
        Инициализация клиента Mistral API
        
        Args:
            base_url: Базовый URL API Mistral
            timeout: Таймаут запросов в секундах
        """
        self.base_url = base_url
        self.timeout = timeout
        logger.info(f'Инициализирован клиент Mistral API с базовым URL: {base_url}')
        
    def generate_text(self, context: List[Dict[str, str]], 
                     temperature: float = 0.7,
                     max_tokens: int = 1000) -> str:
        """
        Синхронная генерация текста на основе контекста
        
        Args:
            context: Список сообщений в формате [{"role": "system", "content": "..."}, ...]
            temperature: Температура генерации (0.0-1.0)
            max_tokens: Максимальное количество токенов в ответе
            
        Returns:
            Сгенерированный ответ
        """
        try:
            # Используем функции из async_utils, если модуль импортирован
            if use_async_utils:
                logger.info(f"Синхронная генерация текста с использованием async_utils")
                return sync_to_async(
                    self.generate_chat_response,
                    messages=context,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
            else:
                # Используем единый подход с nest_asyncio, который позволяет запускать
                # вложенные циклы событий без проблем
                loop = asyncio.get_running_loop() if hasattr(asyncio, 'get_running_loop') else asyncio.get_event_loop()
                
                # Выполняем корутину напрямую - nest_asyncio позволяет запускать
                # run_until_complete даже внутри уже работающего цикла
                logger.info(f"Синхронная генерация текста с использованием nest_asyncio")
                response = loop.run_until_complete(
                    self.generate_chat_response(
                        messages=context,
                        temperature=temperature,
                        max_tokens=max_tokens
                    )
                )
                
                return response
        except RuntimeError as e:
            # Если возникла ошибка с циклом событий
            logger.warning(f"RuntimeError в generate_text: {str(e)}")
            try:
                # Создаем новый цикл в случае ошибки
                logger.info("Создаем новый цикл событий")
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Выполняем асинхронный запрос в синхронном контексте
                response = loop.run_until_complete(
                    self.generate_chat_response(
                        messages=context,
                        temperature=temperature,
                        max_tokens=max_tokens
                    )
                )
                
                # НЕ закрываем цикл событий, так как это может повлиять на другие компоненты
                return response
            except Exception as nested_e:
                logger.error(f"Вложенная ошибка при создании нового цикла: {str(nested_e)}")
                return f"Произошла ошибка при обработке запроса: {str(nested_e)}"
        except Exception as e:
            logger.error(f"Ошибка при синхронной генерации текста: {str(e)}")
            import traceback
            logger.error(f"Трассировка: {traceback.format_exc()}")
            return f"Произошла ошибка при обработке запроса: {str(e)}"
        
    async def generate_response(self, prompt: str, 
                               temperature: float = 0.7, 
                               max_tokens: int = 1000) -> str:
        """
        Генерация ответа на основе промпта
        
        Args:
            prompt: Текст запроса
            temperature: Температура генерации (0.0-1.0)
            max_tokens: Максимальное количество токенов в ответе
            
        Returns:
            Сгенерированный ответ
        """
        try:
            # Формируем запрос в формате llama.cpp
            payload = {
                'prompt': f'<s>[INST] {prompt} [/INST]',
                'n_predict': max_tokens,
                'temperature': temperature,
                'top_p': 0.95,
                'stop': ["</s>", "[INST]"],
                'stream': False
            }
            
            logger.info(f'Отправка запроса на {self.base_url}/completion, длина промпта: {len(prompt)} символов')
            logger.info(f'Payload: {json.dumps(payload)}')
            
            async with aiohttp.ClientSession() as session:
                try:
                    logger.info(f'Начало отправки запроса к {self.base_url}/completion')
                    async with session.post(
                        f'{self.base_url}/completion',
                        json=payload,
                        timeout=self.timeout
                    ) as response:
                        if response.status != 200:
                            error_text = await response.text()
                            logger.error(f'Ошибка при отправке запроса: {response.status}, {error_text}')
                            return f'Произошла ошибка при отправке запроса (код {response.status}). Попробуйте еще раз.'
                        
                        result = await response.json()
                        logger.info(f'Получен ответ: {json.dumps(result)}')
                        
                        # Извлекаем текст ответа
                        if 'content' in result:
                            content = result['content'].strip()
                            logger.info(f'Получен ответ длиной {len(content)} символов')
                            return content
                        else:
                            logger.error(f'Неожиданный формат ответа: {result}')
                            return 'Получен неожиданный формат ответа от модели.'
                except aiohttp.ClientError as e:
                    logger.error(f'Ошибка клиента aiohttp: {str(e)}')
                    return f'Произошла ошибка при подключении к серверу: {str(e)}'
                    
        except asyncio.TimeoutError:
            logger.error(f'Таймаут запроса после {self.timeout} секунд')
            return 'Запрос занял слишком много времени. Пожалуйста, попробуйте еще раз или упростите запрос.'
            
        except Exception as e:
            logger.error(f'Ошибка при генерации ответа: {str(e)}')
            import traceback
            logger.error(f'Трассировка: {traceback.format_exc()}')
            return f'Произошла ошибка: {str(e)}'
    
    async def generate_chat_response(self, 
                                    messages: List[Dict[str, str]], 
                                    temperature: float = 0.7, 
                                    max_tokens: int = 1000) -> str:
        """
        Генерация ответа на основе истории сообщений
        
        Args:
            messages: Список сообщений в формате [{"role": "user", "content": "..."}, ...]
            temperature: Температура генерации (0.0-1.0)
            max_tokens: Максимальное количество токенов в ответе
            
        Returns:
            Сгенерированный ответ
        """
        # Для llama.cpp мы преобразуем историю сообщений в один промпт
        prompt = self._convert_messages_to_prompt(messages)
        return await self.generate_response(prompt, temperature, max_tokens)
    
    def _convert_messages_to_prompt(self, messages: List[Dict[str, str]]) -> str:
        """
        Преобразование истории сообщений в единый промпт для llama.cpp
        
        Args:
            messages: Список сообщений в формате [{"role": "user", "content": "..."}, ...]
            
        Returns:
            Промпт для модели
        """
        if not messages:
            return "Привет! Чем я могу помочь?"
            
        # Извлекаем системный промпт, если он есть
        system_prompt = ""
        user_messages = []
        assistant_messages = []
        
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            elif msg["role"] == "user":
                user_messages.append(msg["content"])
            elif msg["role"] == "assistant":
                assistant_messages.append(msg["content"])
        
        # Строим промпт для Mistral в формате llama.cpp
        formatted_prompt = ""
        
        # Добавляем системный промпт в начало, если он есть
        if system_prompt:
            formatted_prompt = f"{system_prompt}\n\n"
            
        # Добавляем последнее сообщение пользователя
        if user_messages:
            formatted_prompt += user_messages[-1]
            
        logger.info(f"Сформирован промпт длиной {len(formatted_prompt)} символов")
        return formatted_prompt 