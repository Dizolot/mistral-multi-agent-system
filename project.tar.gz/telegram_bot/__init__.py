"""
Пакет telegram_bot для взаимодействия с Telegram API и Mistral.
"""

from . import orchestrator_adapter 